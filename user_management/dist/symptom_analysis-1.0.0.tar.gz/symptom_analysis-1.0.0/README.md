# Symptom Analysis Library

Created for the purpose of ease extraction and use of the library for the purpose of project

##Features include
processing data efficiently.
Analyses the data with given symptom data.

## How to Install

```bash
pip install symptom_analysis