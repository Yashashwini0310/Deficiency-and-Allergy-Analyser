# Symptom Analysis Library

Created for the purpose of ease extraction and use of the library for the purpose of project

##Features include
processing data efficiently.
Analyses the data with given symptom data.

## How to Install

```bash
pip install symptom_analysis

view at:
    https://pypi.org/project/symptom-analysis/1.0.0/
    https://test.pypi.org/project/symptom-analysis/1.0.0/
    
Date: 13-03
previous version of python library had less symptoms. 
New library has a set of known symptoms to check